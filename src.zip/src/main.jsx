console.log(import.meta.env);
import React from "react";
import AOS from "aos";
import "aos/dist/aos.css";


import ReactDOM from "react-dom/client";

import {
    BrowserRouter
}
from "react-router-dom";

import App from "./App";



import {
    CartProvider
}
from "./pos/context/CartContext";

ReactDOM.createRoot(
    document.getElementById("root")
).render(

    <React.StrictMode>

        <CartProvider>

            <BrowserRouter>

                <App />

            </BrowserRouter>

        </CartProvider>

    </React.StrictMode>
);