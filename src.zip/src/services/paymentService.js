import axios from "axios";

const API =
    "http://localhost:8080";

/*
|--------------------------------------------------------------------------
| ADD PAYMENT
|--------------------------------------------------------------------------
*/

export const addPayment =
    async (paymentData) => {

        const response =
            await axios.post(

                `${API}/sales-payments`,

                paymentData,

                {
                    headers: {
                        "Content-Type":
                            "application/json"
                    }
                }
            );

        return response.data;
    };

/*
|--------------------------------------------------------------------------
| GET PAYMENT HISTORY
|--------------------------------------------------------------------------
*/

export const getPaymentsByOrderId =
    async (orderId) => {

        const response =
            await axios.get(

                `${API}/sales-payments/order/${orderId}`
            );

        return response.data;
    };