import React, { useState, useEffect, useRef, useCallback } from "react";
import { calculatePayment, addPayment, getPaymentsByOrderId } from "../../services/paymentService";
import { getInvoice } from "../../services/orderService";

/*
 * PaymentPage.jsx
 * Enterprise POS Payment Collection page.
 *
 * Backend: Spring Boot (Java 17)
 *   - SalesPaymentController  (/sales-payments, /sales-payments/calculate, /sales-payments/order/{id})
 *   - OrderController          (/orders/{id} -> InvoiceResponseDTO)
 *
 * All money math is performed by the backend via POST /sales-payments/calculate.
 * React never computes balance, GST, change, or totals.
 *
 * IMPORTANT — verified against backend source:
 *   - GET /orders/{id} returns an InvoiceResponseDTO with:
 *       orderId, invoiceNumber, customerName, phone, customerAddress,
 *       paymentMethod, totalAmount, paidAmount, balanceAmount,
 *       orderStatus, orderDate, items[], payments[]
 *     There is NO "store" and NO "cashier" field anywhere in this DTO,
 *     in OrderMaster, or in any related entity. The old page read
 *     order.store and order.cashier, which are always undefined.
 *   - "Collected By" is a free-text field on SalesPaymentCreateDTO
 *     (collectedBy). Nothing in the backend derives it automatically,
 *     so it must be entered by the cashier on this page.
 *   - PaymentMethod enum values: CASH, UPI, CARD, IMPS, NEFT, RTGS, CHEQUE.
 *   - /sales-payments/calculate REJECTS (400) a non-CASH amount that
 *     exceeds the remaining balance — it does not cap it. Only CASH
 *     is allowed to exceed the balance (the excess becomes change).
 *   - Error responses are shaped as { timestamp, status, error, message, path }.
 */

const PAYMENT_METHODS = ["CASH", "UPI", "CARD", "IMPS", "NEFT", "RTGS", "CHEQUE"];

const CALCULATE_DEBOUNCE_MS = 400;

let rowIdSeq = 1;
const nextRowId = () => rowIdSeq++;

const emptyRow = () => ({
  id: nextRowId(),
  paymentMethod: "CASH",
  amount: "",
  customerTendered: "",
  transactionNumber: "",
  remarks: "",
});

/* A row is "usable" once it has an amount worth sending to the backend.
   We avoid calling /calculate for rows that are still completely empty —
   the backend treats a missing amount as a validation error, not a "0",
   so calling it on page load with the default blank row just produces
   a scary error banner before the user has typed anything. */
const rowHasValue = (row) =>
  row.paymentMethod === "CASH"
    ? row.customerTendered !== "" && row.customerTendered !== null
    : row.amount !== "" && row.amount !== null;

/* Resolve orderId from the current URL, e.g. /payments/1024 -> "1024" */
const getOrderIdFromUrl = () => {
  const segments = window.location.pathname.split("/").filter(Boolean);
  return segments.length > 0 ? segments[segments.length - 1] : "";
};

/* Format a backend-supplied numeric value for display. No arithmetic. */
const formatCurrency = (value) => {
  if (value === null || value === undefined || value === "") return "—";
  const num = Number(value);
  if (Number.isNaN(num)) return String(value);
  return "₹" + num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const formatDate = (value) => {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

/* Extract a readable message from an axios error, matching the backend's
   ErrorResponse shape: { timestamp, status, error, message, path }. */
const extractBackendErrorMessage = (err) => {
  const body = err?.response?.data;
  if (body) {
    if (Array.isArray(body.errors)) {
      return body.errors
        .map((e) => (typeof e === "string" ? e : e.defaultMessage || e.message || JSON.stringify(e)))
        .join(" • ");
    }
    if (body.message) return body.message;
    if (body.error) return body.error;
  }
  if (err?.response?.status) return `Request failed with status ${err.response.status}`;
  return "Unable to reach the server.";
};

/* Build the payments array payload exactly matching SalesPaymentItemDTO field names. */
const buildPaymentsPayload = (rows) =>
  rows.map((row) => ({
    paymentMethod: row.paymentMethod,
    amount:
      row.paymentMethod === "CASH"
        ? null
        : row.amount === ""
        ? null
        : Number(row.amount),
    customerTendered:
      row.paymentMethod === "CASH"
        ? row.customerTendered === ""
          ? null
          : Number(row.customerTendered)
        : null,
    transactionNumber: row.paymentMethod === "CASH" ? null : row.transactionNumber || null,
    remarks: row.remarks || null,
  }));

const styles = {
  page: {
    minHeight: "100vh",
    background: "#eef1f4",
    fontFamily:
      "'Segoe UI', system-ui, -apple-system, 'Helvetica Neue', Arial, sans-serif",
    color: "#1f2933",
    padding: "0 0 40px 0",
  },
  header: {
    background: "#0f2a43",
    color: "#ffffff",
    padding: "18px 28px",
    display: "flex",
    alignItems: "baseline",
    justifyContent: "space-between",
    boxShadow: "0 2px 6px rgba(15, 42, 67, 0.35)",
  },
  headerTitle: { margin: 0, fontSize: 22, fontWeight: 700, letterSpacing: 0.4 },
  headerOrder: { fontSize: 15, fontWeight: 500, color: "#bcd3e8" },
  layout: {
    display: "flex",
    gap: 20,
    padding: "24px 28px",
    alignItems: "flex-start",
    flexWrap: "wrap",
  },
  card: {
    background: "#ffffff",
    borderRadius: 8,
    boxShadow: "0 1px 4px rgba(31, 41, 51, 0.12)",
    padding: 20,
    boxSizing: "border-box",
  },
  cardTitle: {
    margin: "0 0 16px 0",
    fontSize: 15,
    fontWeight: 700,
    textTransform: "uppercase",
    letterSpacing: 0.8,
    color: "#0f2a43",
    borderBottom: "2px solid #e3e8ee",
    paddingBottom: 10,
  },
  infoRow: {
    display: "flex",
    justifyContent: "space-between",
    padding: "7px 0",
    fontSize: 14,
    borderBottom: "1px dashed #edf0f3",
    gap: 12,
  },
  infoLabel: { color: "#5f6b7a", fontWeight: 500, whiteSpace: "nowrap" },
  infoValue: { fontWeight: 600, textAlign: "right" },
  collectedByRow: {
    display: "flex",
    flexDirection: "column",
    gap: 4,
    padding: "10px 0 4px 0",
  },
  paymentRow: {
    display: "flex",
    gap: 10,
    alignItems: "flex-end",
    padding: "12px 10px",
    border: "1px solid #e3e8ee",
    borderRadius: 6,
    marginBottom: 10,
    background: "#fafbfc",
    flexWrap: "wrap",
  },
  fieldGroup: { display: "flex", flexDirection: "column", gap: 4 },
  fieldLabel: { fontSize: 12, fontWeight: 600, color: "#5f6b7a" },
  input: {
    padding: "8px 10px",
    border: "1px solid #c8d1da",
    borderRadius: 5,
    fontSize: 14,
    outline: "none",
    background: "#ffffff",
    boxSizing: "border-box",
  },
  inputDisabled: {
    padding: "8px 10px",
    border: "1px solid #dde3e9",
    borderRadius: 5,
    fontSize: 14,
    background: "#f1f4f7",
    color: "#98a3ae",
    boxSizing: "border-box",
  },
  select: {
    padding: "8px 10px",
    border: "1px solid #c8d1da",
    borderRadius: 5,
    fontSize: 14,
    background: "#ffffff",
    minWidth: 110,
    boxSizing: "border-box",
  },
  deleteButton: {
    background: "#fdecea",
    color: "#b3261e",
    border: "1px solid #f2b8b5",
    borderRadius: 5,
    padding: "8px 12px",
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer",
  },
  addButton: {
    background: "#eef4fb",
    color: "#0f5cad",
    border: "1px dashed #7fa8d4",
    borderRadius: 6,
    padding: "10px 16px",
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
    width: "100%",
    marginTop: 4,
  },
  summaryRow: {
    display: "flex",
    justifyContent: "space-between",
    padding: "8px 0",
    fontSize: 14,
    borderBottom: "1px dashed #edf0f3",
  },
  summaryLabel: { color: "#5f6b7a", fontWeight: 500 },
  summaryValue: { fontWeight: 700, fontVariantNumeric: "tabular-nums" },
  statusBadge: (completed) => ({
    display: "inline-block",
    padding: "3px 12px",
    borderRadius: 999,
    fontSize: 12,
    fontWeight: 700,
    letterSpacing: 0.4,
    background: completed ? "#e6f4ea" : "#fef3e2",
    color: completed ? "#1e7e34" : "#b26a00",
    border: completed ? "1px solid #b7dfc2" : "1px solid #f3d9a4",
  }),
  changeBox: {
    marginTop: 14,
    padding: "12px 14px",
    background: "#fff8e1",
    border: "1px solid #f0d98c",
    borderRadius: 6,
    fontSize: 14,
    display: "flex",
    alignItems: "flex-start",
    gap: 10,
  },
  collectButton: (enabled) => ({
    width: "100%",
    marginTop: 16,
    padding: "13px 0",
    fontSize: 16,
    fontWeight: 700,
    letterSpacing: 0.4,
    border: "none",
    borderRadius: 6,
    cursor: enabled ? "pointer" : "not-allowed",
    background: enabled ? "#1e7e34" : "#c3ccd4",
    color: "#ffffff",
    transition: "background 0.15s ease",
  }),
  invoiceButton: {
    width: "100%",
    marginTop: 16,
    padding: "13px 0",
    fontSize: 16,
    fontWeight: 700,
    letterSpacing: 0.4,
    border: "none",
    borderRadius: 6,
    cursor: "pointer",
    background: "#0f5cad",
    color: "#ffffff",
  },
  errorBanner: {
    margin: "0 28px",
    padding: "12px 16px",
    background: "#fdecea",
    border: "1px solid #f2b8b5",
    borderRadius: 6,
    color: "#b3261e",
    fontSize: 14,
    fontWeight: 500,
  },
  successBanner: {
    margin: "0 28px",
    padding: "12px 16px",
    background: "#e6f4ea",
    border: "1px solid #b7dfc2",
    borderRadius: 6,
    color: "#1e7e34",
    fontSize: 14,
    fontWeight: 600,
  },
  table: { width: "100%", borderCollapse: "collapse", fontSize: 13, marginTop: 4 },
  th: {
    textAlign: "left",
    padding: "8px 10px",
    background: "#f1f4f7",
    color: "#5f6b7a",
    fontWeight: 700,
    borderBottom: "2px solid #e3e8ee",
    whiteSpace: "nowrap",
  },
  td: {
    padding: "8px 10px",
    borderBottom: "1px solid #edf0f3",
    verticalAlign: "top",
  },
  emptyHistory: {
    padding: "16px 0",
    textAlign: "center",
    color: "#98a3ae",
    fontSize: 13,
  },
  calcHint: {
    fontSize: 12,
    color: "#98a3ae",
    marginTop: 8,
    minHeight: 16,
  },
};

export default function PaymentPage() {
  const [orderId] = useState(getOrderIdFromUrl);

  const [order, setOrder] = useState(null);
  const [orderLoading, setOrderLoading] = useState(true);

  const [rows, setRows] = useState(() => [emptyRow()]);
  const [collectedBy, setCollectedBy] = useState("");

  const [calculation, setCalculation] = useState(null);
  const [calculating, setCalculating] = useState(false);

  const [history, setHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(true);

  const [changeConfirmed, setChangeConfirmed] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveResult, setSaveResult] = useState(null);

  const [errorMessage, setErrorMessage] = useState("");

  const debounceTimer = useRef(null);
  const calcRequestSeq = useRef(0);

  /* ---------------- Load order / invoice information ---------------- */
  useEffect(() => {
    if (!orderId) {
      setErrorMessage("No order id found in the URL.");
      setOrderLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      setOrderLoading(true);
      try {
       const data = await getInvoice(orderId);
        if (!cancelled) setOrder(data);
      } catch (err) {
        if (!cancelled) setErrorMessage(extractBackendErrorMessage(err));
      } finally {
        if (!cancelled) setOrderLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [orderId]);

  /* ---------------- Load payment history ---------------- */
  const loadHistory = useCallback(async () => {
    if (!orderId) return;
    setHistoryLoading(true);
    try {
      const data = await getPaymentsByOrderId(orderId);
      setHistory(Array.isArray(data) ? data : []);
    } catch (err) {
      setErrorMessage(extractBackendErrorMessage(err));
    } finally {
      setHistoryLoading(false);
    }
  }, [orderId]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  /* ---------------- Backend calculation (debounced 400ms) ---------------- */
  const runCalculation = useCallback(
    async (currentRows) => {
      if (!orderId) return;

      // Nothing entered yet — don't hit the backend, and clear any stale result.
      if (!currentRows.some(rowHasValue)) {
        calcRequestSeq.current += 1;
        setCalculation(null);
        setCalculating(false);
        return;
      }

      const seq = ++calcRequestSeq.current;
      setCalculating(true);
      try {
        const data = await calculatePayment({
          orderId,
          payments: buildPaymentsPayload(currentRows),
        });
        if (seq !== calcRequestSeq.current) return; // stale response, ignore
        setErrorMessage("");
        setCalculation(data);
      } catch (err) {
        if (seq === calcRequestSeq.current) {
          setErrorMessage(extractBackendErrorMessage(err));
          setCalculation(null);
        }
      } finally {
        if (seq === calcRequestSeq.current) setCalculating(false);
      }
    },
    [orderId]
  );

  useEffect(() => {
    if (saved) return; // no recalculation after a successful save
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => {
      runCalculation(rows);
    }, CALCULATE_DEBOUNCE_MS);
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [rows, runCalculation, saved]);

  /* Reset the change confirmation whenever the backend result changes. */
  useEffect(() => {
    setChangeConfirmed(false);
  }, [calculation?.changeReturn]);

  /* ---------------- Row handlers ---------------- */
  const updateRow = (id, field, value) => {
    setRows((prev) =>
      prev.map((row) => {
        if (row.id !== id) return row;
        if (field === "paymentMethod") {
          // Switching method clears fields that no longer apply.
          if (value === "CASH") {
            return { ...row, paymentMethod: value, amount: "", transactionNumber: "" };
          }
          return { ...row, paymentMethod: value, customerTendered: "" };
        }
        return { ...row, [field]: value };
      })
    );
  };

  const addRow = () => setRows((prev) => [...prev, emptyRow()]);

  const deleteRow = (id) =>
    setRows((prev) => (prev.length > 1 ? prev.filter((row) => row.id !== id) : prev));

  /* ---------------- Save payment ---------------- */
  const changeReturn = Number(calculation?.changeReturn ?? 0);
  const paymentCompleted = calculation?.paymentCompleted === true;
  const needsChangeConfirmation = changeReturn > 0;
  const canCollect =
    paymentCompleted && (!needsChangeConfirmation || changeConfirmed) && !saving && !saved;

  const handleCollectPayment = async () => {
    if (!canCollect) return;
    setSaving(true);
    setErrorMessage("");
    try {
      const data = await addPayment({
        orderId,
        collectedBy: collectedBy.trim() || null,
        payments: buildPaymentsPayload(rows),
      });
      setSaveResult(data);
      setSaved(true);
      await loadHistory();
    } catch (err) {
      setErrorMessage(extractBackendErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleViewInvoice = () => {
    window.location.href = `/invoice/${orderId}`;
  };

  /* ---------------- Derived display values (backend-supplied only) ---------------- */
  const summary = saved && saveResult ? saveResult : calculation;

  const orderNumber = order?.invoiceNumber ?? orderId;

  /* ---------------- Render ---------------- */
  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <h1 style={styles.headerTitle}>Payment Collection</h1>
        <span style={styles.headerOrder}>
          Order&nbsp;#&nbsp;{orderLoading ? "…" : orderNumber}
        </span>
      </header>

      {errorMessage ? (
        <div style={{ ...styles.errorBanner, marginTop: 20 }} role="alert">
          {errorMessage}
        </div>
      ) : null}

      {saved ? (
        <div style={{ ...styles.successBanner, marginTop: 20 }} role="status">
          Payment collected successfully.
          {saveResult?.orderStatus ? ` Order status: ${saveResult.orderStatus}.` : ""}
        </div>
      ) : null}

      <div style={styles.layout}>
        {/* ---------------- LEFT CARD: Order Information ---------------- */}
        <section style={{ ...styles.card, flex: "1 1 260px", minWidth: 260 }}>
          <h2 style={styles.cardTitle}>Order Information</h2>
          {orderLoading ? (
            <div style={styles.emptyHistory}>Loading order…</div>
          ) : order ? (
            <div>
              <div style={styles.infoRow}>
                <span style={styles.infoLabel}>Customer Name</span>
                <span style={styles.infoValue}>{order.customerName ?? "—"}</span>
              </div>
              <div style={styles.infoRow}>
                <span style={styles.infoLabel}>Phone</span>
                <span style={styles.infoValue}>{order.phone ?? "—"}</span>
              </div>
              <div style={styles.infoRow}>
                <span style={styles.infoLabel}>Address</span>
                <span style={styles.infoValue}>{order.customerAddress ?? "—"}</span>
              </div>
              <div style={styles.infoRow}>
                <span style={styles.infoLabel}>Order Date</span>
                <span style={styles.infoValue}>{formatDate(order.orderDate)}</span>
              </div>
              <div style={styles.infoRow}>
                <span style={styles.infoLabel}>Order Status</span>
                <span style={styles.infoValue}>{order.orderStatus ?? "—"}</span>
              </div>
              <div style={{ ...styles.infoRow, borderBottom: "none" }}>
                <span style={styles.infoLabel}>Original Payment Method</span>
                <span style={styles.infoValue}>{order.paymentMethod ?? "—"}</span>
              </div>

              <div style={styles.collectedByRow}>
                <label htmlFor="collected-by" style={styles.fieldLabel}>
                  Collected By
                </label>
                <input
                  id="collected-by"
                  style={styles.input}
                  type="text"
                  placeholder="Cashier / staff name"
                  value={collectedBy}
                  disabled={saved}
                  onChange={(e) => setCollectedBy(e.target.value)}
                />
              </div>
            </div>
          ) : (
            <div style={styles.emptyHistory}>Order details are unavailable.</div>
          )}
        </section>

        {/* ---------------- CENTER CARD: Payment Entry ---------------- */}
        <section style={{ ...styles.card, flex: "2 1 480px", minWidth: 360 }}>
          <h2 style={styles.cardTitle}>Payment Entry</h2>

          {rows.map((row) => {
            const isCash = row.paymentMethod === "CASH";
            return (
              <div key={row.id} style={styles.paymentRow}>
                <div style={styles.fieldGroup}>
                  <label htmlFor={`method-${row.id}`} style={styles.fieldLabel}>
                    Payment Method
                  </label>
                  <select
                    id={`method-${row.id}`}
                    style={styles.select}
                    value={row.paymentMethod}
                    disabled={saved}
                    onChange={(e) => updateRow(row.id, "paymentMethod", e.target.value)}
                  >
                    {PAYMENT_METHODS.map((method) => (
                      <option key={method} value={method}>
                        {method}
                      </option>
                    ))}
                  </select>
                </div>

                {isCash ? (
                  <div style={styles.fieldGroup}>
                    <label htmlFor={`tendered-${row.id}`} style={styles.fieldLabel}>
                      Customer Gives
                    </label>
                    <input
                      id={`tendered-${row.id}`}
                      style={{ ...styles.input, width: 130 }}
                      type="number"
                      min="0"
                      step="0.01"
                      inputMode="decimal"
                      placeholder="0.00"
                      value={row.customerTendered}
                      disabled={saved}
                      onChange={(e) => updateRow(row.id, "customerTendered", e.target.value)}
                    />
                  </div>
                ) : (
                  <div style={styles.fieldGroup}>
                    <label htmlFor={`amount-${row.id}`} style={styles.fieldLabel}>
                      Amount
                    </label>
                    <input
                      id={`amount-${row.id}`}
                      style={{ ...styles.input, width: 130 }}
                      type="number"
                      min="0"
                      step="0.01"
                      inputMode="decimal"
                      placeholder="0.00"
                      value={row.amount}
                      disabled={saved}
                      onChange={(e) => updateRow(row.id, "amount", e.target.value)}
                    />
                  </div>
                )}

                <div style={styles.fieldGroup}>
                  <label htmlFor={`txn-${row.id}`} style={styles.fieldLabel}>
                    Reference Number
                  </label>
                  <input
                    id={`txn-${row.id}`}
                    style={isCash ? { ...styles.inputDisabled, width: 160 } : { ...styles.input, width: 160 }}
                    type="text"
                    placeholder={isCash ? "Not required for cash" : "Transaction / ref no."}
                    value={isCash ? "" : row.transactionNumber}
                    disabled={isCash || saved}
                    onChange={(e) => updateRow(row.id, "transactionNumber", e.target.value)}
                  />
                </div>

                <div style={{ ...styles.fieldGroup, flex: "1 1 140px" }}>
                  <label htmlFor={`remarks-${row.id}`} style={styles.fieldLabel}>
                    Remarks
                  </label>
                  <input
                    id={`remarks-${row.id}`}
                    style={{ ...styles.input, width: "100%" }}
                    type="text"
                    placeholder="Optional remarks"
                    value={row.remarks}
                    disabled={saved}
                    onChange={(e) => updateRow(row.id, "remarks", e.target.value)}
                  />
                </div>

                <button
                  type="button"
                  style={{
                    ...styles.deleteButton,
                    opacity: rows.length > 1 && !saved ? 1 : 0.5,
                    cursor: rows.length > 1 && !saved ? "pointer" : "not-allowed",
                  }}
                  disabled={rows.length <= 1 || saved}
                  onClick={() => deleteRow(row.id)}
                  aria-label="Delete payment row"
                >
                  Delete
                </button>
              </div>
            );
          })}

          <button type="button" style={styles.addButton} onClick={addRow} disabled={saved}>
            + Add Payment Method
          </button>

          <div style={styles.calcHint}>
            {calculating ? "Calculating with server…" : ""}
          </div>
        </section>

        {/* ---------------- RIGHT CARD: Payment Summary ---------------- */}
        <section style={{ ...styles.card, flex: "1 1 280px", minWidth: 280 }}>
          <h2 style={styles.cardTitle}>Payment Summary</h2>

          <div style={styles.summaryRow}>
            <span style={styles.summaryLabel}>Invoice Amount</span>
            <span style={styles.summaryValue}>{formatCurrency(summary?.invoiceAmount)}</span>
          </div>
          <div style={styles.summaryRow}>
            <span style={styles.summaryLabel}>Already Paid</span>
            <span style={styles.summaryValue}>{formatCurrency(summary?.alreadyPaid)}</span>
          </div>
          <div style={styles.summaryRow}>
            <span style={styles.summaryLabel}>Entered Amount</span>
            <span style={styles.summaryValue}>{formatCurrency(calculation?.enteredAmount)}</span>
          </div>
          <div style={styles.summaryRow}>
            <span style={styles.summaryLabel}>Applied Amount</span>
            <span style={styles.summaryValue}>{formatCurrency(calculation?.appliedAmount)}</span>
          </div>
          <div style={styles.summaryRow}>
            <span style={styles.summaryLabel}>Balance Amount</span>
            <span style={styles.summaryValue}>{formatCurrency(summary?.balanceAmount)}</span>
          </div>
          <div style={styles.summaryRow}>
            <span style={styles.summaryLabel}>Change Return</span>
            <span style={styles.summaryValue}>{formatCurrency(summary?.changeReturn)}</span>
          </div>
          <div style={{ ...styles.summaryRow, borderBottom: "none" }}>
            <span style={styles.summaryLabel}>Payment Status</span>
            <span>
              <span style={styles.statusBadge(saved || paymentCompleted)}>
                {saved
                  ? saveResult?.orderStatus ?? "PAID"
                  : paymentCompleted
                  ? "READY TO COLLECT"
                  : "PENDING"}
              </span>
            </span>
          </div>

          {!saved && needsChangeConfirmation ? (
            <div style={styles.changeBox}>
              <input
                id="change-confirmation"
                type="checkbox"
                checked={changeConfirmed}
                onChange={(e) => setChangeConfirmed(e.target.checked)}
                style={{ marginTop: 3, width: 16, height: 16, cursor: "pointer" }}
              />
              <label htmlFor="change-confirmation" style={{ cursor: "pointer" }}>
                I confirm I returned {formatCurrency(changeReturn)} change to the customer.
              </label>
            </div>
          ) : null}

          {saved ? (
            <button type="button" style={styles.invoiceButton} onClick={handleViewInvoice}>
              View Invoice
            </button>
          ) : (
            <button
              type="button"
              style={styles.collectButton(canCollect)}
              disabled={!canCollect}
              onClick={handleCollectPayment}
            >
              {saving ? "Collecting…" : "Collect Payment"}
            </button>
          )}
        </section>
      </div>

      {/* ---------------- PAYMENT HISTORY ---------------- */}
      <div style={{ padding: "0 28px" }}>
        <section style={{ ...styles.card, width: "100%" }}>
          <h2 style={styles.cardTitle}>Payment History</h2>
          {historyLoading ? (
            <div style={styles.emptyHistory}>Loading payment history…</div>
          ) : history.length === 0 ? (
            <div style={styles.emptyHistory}>No payments recorded for this order yet.</div>
          ) : (
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Method</th>
                  <th style={styles.th}>Amount</th>
                  <th style={styles.th}>Transaction Number</th>
                  <th style={styles.th}>Collected By</th>
                  <th style={styles.th}>Date</th>
                </tr>
              </thead>
              <tbody>
                {history.map((payment, index) => (
                  <tr key={payment.id ?? index}>
                    <td style={styles.td}>{payment.paymentMethod ?? "—"}</td>
                    <td style={{ ...styles.td, fontVariantNumeric: "tabular-nums" }}>
                      {formatCurrency(payment.amount)}
                    </td>
                    <td style={styles.td}>{payment.transactionNumber ?? "—"}</td>
                    <td style={styles.td}>{payment.collectedBy ?? "—"}</td>
                    <td style={styles.td}>{formatDate(payment.paymentDate)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </div>
    </div>
  );
}
