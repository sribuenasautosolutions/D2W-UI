import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { placeOrder } from "../../services/orderService";
import { getCustomerByMobile, saveCustomer } from "../../services/customerService";

function CheckoutPage() {
  const navigate = useNavigate();
  const {
    cartItems,
    increaseQuantity,
    decreaseQuantity,
    removeFromCart,
    updateDiscount,
    clearCart,
  } = useCart();

  const [customerExists, setCustomerExists] = useState(false);
  const [customerSaved, setCustomerSaved] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");

  const [billDiscount, setBillDiscount] = useState(0);

  const subTotal = cartItems.reduce(
    (t, i) => t + i.sellingPrice * i.quantity,
    0
  );

  const itemDiscountTotal = cartItems.reduce(
    (t, i) =>
      t + (i.sellingPrice * i.quantity * (i.itemDiscount || 0)) / 100,
    0
  );

  const gstTotal = cartItems.reduce((t, i) => {
    const base = i.sellingPrice * i.quantity;
    const gstPercent = Number(i.gstPercentage || 0);
    return t + (base - base / (1 + gstPercent / 100));
  }, 0);

  const afterItemDisc = subTotal - itemDiscountTotal;
  const billDiscountAmount = afterItemDisc * (Number(billDiscount || 0)) / 100;
  const netPayable = afterItemDisc - billDiscountAmount;

  const handleMobileChange = async (mobile) => {
    setPhone(mobile);

    if (mobile.length !== 10) {
      setCustomerName("");
      setCustomerExists(false);
      return;
    }

    try {
      const customer = await getCustomerByMobile(mobile);

      if (customer) {
        setCustomerName(customer.customerName);
        setCustomerExists(true);
      } else {
        setCustomerName("");
        setCustomerExists(false);
      }
    } catch (error) {
      console.error(error);
      setCustomerExists(false);
    }
  };

  const handleSaveCustomer = async () => {
    try {
      await saveCustomer({
        customerName,
        mobileNumber: phone,
      });

      setCustomerSaved(true);
      setCustomerExists(true);
      alert("Customer Saved Successfully");
    } catch (error) {
      console.error(error);
      alert("Customer Save Failed");
    }
  };

  const handlePlaceOrder = async () => {
    // --- Validation ---
    if (cartItems.length === 0) {
      alert("Cart is empty. Please add at least one item before creating an invoice.");
      return;
    }

    if (!customerName.trim()) {
      alert("Customer name is required.");
      return;
    }

    if (!/^\d{10}$/.test(phone)) {
      alert("Please enter a valid 10-digit mobile number.");
      return;
    }

    try {
      const user = JSON.parse(localStorage.getItem("user"));
      const orderData = {
        storeId: user.storeId,
        customerName,
        phone,
        email,
        address,
        totalAmount: Number(netPayable),
        billDiscountPercent: Number(billDiscount || 0),
        billDiscountAmount: Number(billDiscountAmount),
        items: cartItems.map((item) => ({
          productId: item.productId || item.id,
          quantity: item.quantity,
          sellingPrice: Number(item.sellingPrice),
          gstPercentage: Number(item.gstPercentage || 0),
          discountPercentage: Number(item.itemDiscount || 0),
          hsnCode: item.hsnCode || item.hsncode || "",
          totalPrice: Number(
            item.sellingPrice * item.quantity * (1 - (item.itemDiscount || 0) / 100)
          ),
        })),
      };

      const orderId = await placeOrder(orderData);
      clearCart();
      navigate(`/pos/payment/${orderId}`);
    } catch (error) {
      console.error(error);
      alert("Invoice Creation Failed");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#f1f5f9", padding: "16px", fontFamily: "sans-serif" }}>

      {/* TOP BAR */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
        <button
          onClick={() => navigate(-1)}
          style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "13px", color: "#64748b", cursor: "pointer", border: "1px solid #e2e8f0", borderRadius: "8px", padding: "6px 14px", background: "#fff" }}
        >
          ← Back to POS
        </button>
        <h2 style={{ fontSize: "20px", fontWeight: "600", color: "#0f172a" }}>Checkout</h2>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <div style={{ width: "36px", height: "36px", background: "#fee2e2", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "20px" }}>🚗</div>
          <div>
            <div style={{ fontSize: "14px", fontWeight: "600", color: "#0f172a" }}>Smart Auto Parts</div>
            <div style={{ fontSize: "11px", color: "#64748b" }}>Automobile Spare Parts Store</div>
          </div>
        </div>
      </div>

      {/* MAIN GRID */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>

        {/* LEFT — CUSTOMER DETAILS */}
        <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: "12px", padding: "18px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px", paddingBottom: "12px", borderBottom: "1px solid #f1f5f9" }}>
            <div style={{ width: "36px", height: "36px", background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px" }}>👤</div>
            <div>
              <div style={{ fontSize: "15px", fontWeight: "600", color: "#0f172a" }}>Customer Details</div>
              <div style={{ fontSize: "12px", color: "#94a3b8" }}>Enter customer information</div>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "10px", marginBottom: "12px" }}>
            <div>
              <label style={labelStyle}>Mobile Number *</label>
              <input
                type="text"
                placeholder="Enter 10digit mobileNumber"
                value={phone}
                onChange={(e) => handleMobileChange(e.target.value)}
                style={inputStyle}
              />
            </div>
          </div>

          <div style={{ marginBottom: "12px" }}>
            <label style={{ fontSize: "12px", fontWeight: "500", color: "#64748b", display: "block", marginBottom: "5px" }}>Customer Name *</label>
            <input
              type="text"
              placeholder="Enter Your Name"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              style={inputStyle}
            />
          </div>

          {!customerExists &&
            /^\d{10}$/.test(phone) &&
            customerName.trim() !== "" && (
              <button
                onClick={handleSaveCustomer}
                style={{
                  width: "100%",
                  marginTop: "10px",
                  padding: "10px",
                  background: "#2563eb",
                  color: "#fff",
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                }}
              >
                Save Customer
              </button>
            )}

          {/* PAYMENT INFORMATION BOX */}
          <div
            style={{
              marginTop: "18px",
              border: "1px solid #bfdbfe",
              borderRadius: "10px",
              padding: "14px 16px",
              background: "#eff6ff",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                marginBottom: "6px",
              }}
            >
              <span style={{ fontSize: "18px" }}>💳</span>
              <span
                style={{
                  fontSize: "14px",
                  fontWeight: "600",
                  color: "#1d4ed8",
                }}
              >
                Payment Information
              </span>
            </div>
            <p
              style={{
                margin: 0,
                fontSize: "13px",
                color: "#3b82f6",
                lineHeight: "1.5",
              }}
            >
              Payment will be collected after invoice creation.
            </p>
          </div>
        </div>

        {/* RIGHT — ORDER SUMMARY */}
        <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: "12px", padding: "18px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px", paddingBottom: "12px", borderBottom: "1px solid #f1f5f9" }}>
            <div style={{ width: "36px", height: "36px", background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px" }}>🛒</div>
            <div>
              <div style={{ fontSize: "15px", fontWeight: "600", color: "#0f172a" }}>Order Summary</div>
              <div style={{ fontSize: "12px", color: "#94a3b8" }}>Review your items and order details</div>
            </div>
          </div>

          {/* TABLE HEADER */}
          <div style={{ display: "grid", gridTemplateColumns: "2fr 70px 70px 50px 80px 65px 28px", gap: "6px", fontSize: "11px", fontWeight: "500", color: "#94a3b8", padding: "6px 0", borderBottom: "1px solid #f1f5f9", marginBottom: "4px" }}>
            <div>Product</div>
            <div style={{ textAlign: "center" }}>Qty</div>
            <div style={{ textAlign: "right" }}>Price</div>
            <div style={{ textAlign: "center" }}>GST</div>
            <div style={{ textAlign: "center" }}>Discount</div>
            <div style={{ textAlign: "right" }}>Amount</div>
            <div></div>
          </div>

          {/* CART ROWS */}
          {cartItems.map((item) => {
            const itemTotal = item.sellingPrice * item.quantity * (1 - (item.itemDiscount || 0) / 100);
            return (
              <div
                key={item.productId}
                style={{ display: "grid", gridTemplateColumns: "2fr 70px 70px 50px 80px 65px 28px", gap: "6px", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #f8fafc" }}
              >
                <div>
                  <div style={{ fontSize: "13px", fontWeight: "600", color: "#0f172a" }}>{item.itemName}</div>
                  {(item.partNo || item.partNumber) && (
                    <div style={{ fontSize: "11px", color: "#3b82f6" }}>
                      Part No: {item.partNo || item.partNumber}
                    </div>
                  )}
                  {(item.hsnCode || item.hsncode) && (
                    <div style={{ fontSize: "11px", color: "#94a3b8" }}>
                      HSN : {item.hsnCode || item.hsncode}
                    </div>
                  )}
                </div>

                <div style={{ display: "flex", alignItems: "center", gap: "4px", justifyContent: "center" }}>
                  <button onClick={() => decreaseQuantity(item.productId)} style={qtyBtnStyle}>−</button>
                  <span style={{ fontSize: "13px", fontWeight: "600", color: "#0f172a", minWidth: "16px", textAlign: "center" }}>{item.quantity}</span>
                  <button onClick={() => increaseQuantity(item.productId)} style={qtyBtnStyle}>+</button>
                </div>

                <div style={{ textAlign: "right", fontSize: "13px", color: "#0f172a" }}>₹{Number(item.sellingPrice).toFixed(2)}</div>

                <div style={{ textAlign: "center", fontSize: "13px", color: "#64748b" }}>{item.gstPercentage || 0}%</div>

                <div style={{ display: "flex", alignItems: "center", gap: "3px", justifyContent: "center" }}>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={item.itemDiscount || 0}
                    onChange={(e) => updateDiscount(item.productId, e.target.value)}
                    style={{ width: "46px", padding: "4px 6px", fontSize: "12px", border: "1px solid #e2e8f0", borderRadius: "6px", textAlign: "center", outline: "none" }}
                  />
                  <span style={{ fontSize: "11px", color: "#94a3b8" }}>%</span>
                </div>

                <div style={{ textAlign: "right", fontSize: "13px", fontWeight: "600", color: "#0f172a" }}>₹{itemTotal.toFixed(2)}</div>

                <button
                  onClick={() => removeFromCart(item.productId)}
                  style={{ background: "none", border: "none", cursor: "pointer", color: "#ef4444", fontSize: "15px", padding: "2px", display: "flex", alignItems: "center" }}
                >
                  🗑️
                </button>
              </div>
            );
          })}

          {/* BILL SUMMARY */}
          <div style={{ marginTop: "14px" }}>
            <div style={summaryRowStyle}>
              <span>Sub Total ({cartItems.length} items)</span>
              <span>₹{subTotal.toFixed(2)}</span>
            </div>
            <div style={{ ...summaryRowStyle, color: "#ef4444" }}>
              <span>Item Discount</span>
              <span>- ₹{itemDiscountTotal.toFixed(2)}</span>
            </div>
            <div style={summaryRowStyle}>
              <span>GST Included</span>
              <span>₹{gstTotal.toFixed(2)}</span>
            </div>

            {/* BILL DISCOUNT — PERCENTAGE INPUT */}
            <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "8px", padding: "10px 12px", margin: "10px 0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ fontSize: "13px", color: "#64748b", display: "flex", alignItems: "center", gap: "6px" }}>
                🏷️ Bill Discount (%)
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={billDiscount}
                  onChange={(e) => setBillDiscount(e.target.value)}
                  style={{ width: "64px", padding: "5px 8px", fontSize: "13px", border: "1px solid #e2e8f0", borderRadius: "6px", textAlign: "right", outline: "none" }}
                />
                <span style={{ fontSize: "12px", color: "#94a3b8" }}>%</span>
                <span style={{ fontSize: "13px", color: "#ef4444", fontWeight: "600", minWidth: "70px", textAlign: "right" }}>
                  - ₹{billDiscountAmount.toFixed(2)}
                </span>
              </div>
            </div>

            {/* NET PAYABLE */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0 4px", borderTop: "1px solid #e2e8f0", marginTop: "8px" }}>
              <span style={{ fontSize: "15px", fontWeight: "600", color: "#0f172a" }}>Net Payable</span>
              <span style={{ fontSize: "22px", fontWeight: "700", color: "#16a34a" }}>₹{netPayable.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "16px", gap: "12px" }}>
        <button
          onClick={() => navigate(-1)}
          style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "13px", color: "#64748b", cursor: "pointer", border: "1px solid #e2e8f0", borderRadius: "8px", padding: "11px 20px", background: "#fff" }}
        >
          ← Back to POS
        </button>
        <button
          onClick={handlePlaceOrder}
          style={{ flex: 1, maxWidth: "400px", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", background: "#1e293b", color: "#fff", border: "none", borderRadius: "8px", padding: "13px 32px", fontSize: "14px", fontWeight: "600", cursor: "pointer" }}
        >
          🧾Check Out
        </button>
      </div>
    </div>
  );
}

const inputStyle = {
  width: "100%",
  padding: "9px 11px",
  fontSize: "13px",
  border: "1px solid #e2e8f0",
  borderRadius: "8px",
  background: "#fff",
  color: "#0f172a",
  outline: "none",
  fontFamily: "sans-serif",
};

const labelStyle = {
  fontSize: "12px",
  fontWeight: "500",
  color: "#64748b",
  display: "block",
  marginBottom: "5px",
};

const qtyBtnStyle = {
  width: "22px",
  height: "22px",
  border: "1px solid #e2e8f0",
  borderRadius: "6px",
  background: "#f8fafc",
  fontSize: "13px",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color: "#0f172a",
};

const summaryRowStyle = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  fontSize: "13px",
  color: "#64748b",
  padding: "5px 0",
};

export default CheckoutPage;
