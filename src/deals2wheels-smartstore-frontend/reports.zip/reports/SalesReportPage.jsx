import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getSalesReport, getSalesOrders } from "../../services/reportService";
import {
  getSalesReport,
  getSalesOrders,
  getTopProducts,
  getTopCategories,
  getTopBrands,
  getTopVehicles
} from "../../services/reportService";

/* ── shared tokens ── */
const [topProducts, setTopProducts] = useState([]);
const [topCategories, setTopCategories] = useState([]);
const [topBrands, setTopBrands] = useState([]);
const [topVehicles, setTopVehicles] = useState([]);
const S = {
  page: { padding: "28px 30px", background: "#f1f5f9", minHeight: "100vh", fontFamily: "'Segoe UI',sans-serif" },
  breadcrumb: { fontSize: "13px", color: "#94a3b8", marginBottom: "2px" },
  pageTitle: { fontSize: "24px", fontWeight: "700", color: "#0f172a", margin: 0 },

  /* stat cards */
  cardGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(210px,1fr))", gap: "20px", margin: "24px 0" },
  card: (bg) => ({
    background: bg,
    borderRadius: "10px",
    padding: "20px 22px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    color: "#fff",
    boxShadow: "0 2px 10px rgba(0,0,0,0.10)",
  }),
  cardLeft: { display: "flex", flexDirection: "column" },
  cardLabel: { fontSize: "13px", opacity: 0.9, marginBottom: "6px" },
  cardValue: { fontSize: "26px", fontWeight: "800", margin: 0 },
  cardIcon: {
    width: "52px", height: "52px", borderRadius: "50%",
    background: "rgba(255,255,255,0.2)",
    display: "flex", alignItems: "center", justifyContent: "center", fontSize: "22px",
  },

  /* toolbar */
  toolbar: {
    background: "#fff", borderRadius: "10px", padding: "16px 20px",
    display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap",
    marginBottom: "20px", boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
  },
  label: { fontSize: "12px", color: "#64748b", marginBottom: "2px" },
  input: {
    padding: "7px 10px", border: "1px solid #d1d5db", borderRadius: "6px",
    fontSize: "13px", color: "#0f172a", background: "#fff",
  },
  quickBtn: (active) => ({
    padding: "7px 12px", borderRadius: "6px", border: "1px solid #e2e8f0",
    background: active ? "#2563eb" : "#fff", color: active ? "#fff" : "#64748b",
    fontSize: "12px", cursor: "pointer", fontWeight: "500",
  }),
  searchBtn: {
    padding: "8px 20px", borderRadius: "6px", border: "none",
    background: "#2563eb", color: "#fff", fontWeight: "600", fontSize: "13px", cursor: "pointer",
  },
  exportPdf: {
    padding: "8px 14px", borderRadius: "6px", border: "none",
    background: "#fee2e2", color: "#dc2626", fontWeight: "600", fontSize: "12px", cursor: "pointer",
    display: "flex", alignItems: "center", gap: "5px", marginLeft: "auto",
  },
  exportExcel: {
    padding: "8px 14px", borderRadius: "6px", border: "none",
    background: "#dcfce7", color: "#16a34a", fontWeight: "600", fontSize: "12px", cursor: "pointer",
    display: "flex", alignItems: "center", gap: "5px",
  },

  /* table */
  tableWrap: { background: "#fff", borderRadius: "10px", padding: "20px", boxShadow: "0 1px 4px rgba(0,0,0,0.06)" },
  tableTitle: { fontSize: "16px", fontWeight: "700", color: "#0f172a", marginBottom: "16px" },
  th: {
    padding: "12px 14px", textAlign: "left", fontSize: "13px",
    fontWeight: "600", color: "#64748b", background: "#f8fafc", borderBottom: "1px solid #e2e8f0",
  },
  td: { padding: "12px 14px", fontSize: "13px", color: "#374151", borderBottom: "1px solid #f1f5f9" },

  /* pagination */
  pag: { display: "flex", justifyContent: "flex-end", alignItems: "center", gap: "6px", marginTop: "18px" },
  pagBtn: (active) => ({
    width: "32px", height: "32px", borderRadius: "6px", border: "1px solid #e2e8f0",
    background: active ? "#2563eb" : "#fff", color: active ? "#fff" : "#374151",
    cursor: "pointer", fontSize: "13px", fontWeight: active ? "700" : "400",
    display: "flex", alignItems: "center", justifyContent: "center",
  }),
};

const QUICK = ["Today", "Yesterday", "This Week", "This Month", "Custom"];

function SalesReportPage() {
  const navigate = useNavigate();
  const [salesReport, setSalesReport] = useState(null);
  const [salesOrders, setSalesOrders] = useState([]);
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [activeQuick, setActiveQuick] = useState("This Month");
  const [fromDate, setFromDate] = useState("2026-06-01");
  const [toDate, setToDate] = useState("2026-06-08");
  const itemsPerPage = 10;
  const products = await getTopProducts();
const categories = await getTopCategories();
const brands = await getTopBrands();
const vehicles = await getTopVehicles();

setTopProducts(products);
setTopCategories(categories);
setTopBrands(brands);
setTopVehicles(vehicles);

  useEffect(() => { loadSalesReport(); }, []);

  const loadSalesReport = async () => {
    try {
      const reportData = await getSalesReport();
      const orderData = await getSalesOrders();
      setSalesReport(reportData);
      setSalesOrders(orderData);
    } catch (error) { console.error(error); }
  };

  if (!salesReport) return <div style={{ padding: "30px" }}>Loading Sales Report...</div>;

  const averageOrderValue = salesReport.totalOrders > 0
    ? (salesReport.totalRevenue / salesReport.totalOrders).toFixed(2) : 0;

  const filteredOrders = salesOrders.filter((o) =>
    o.customerName?.toLowerCase().includes(search.toLowerCase())
  );
  const totalPages = Math.ceil(filteredOrders.length / itemsPerPage) || 1;
  const currentOrders = filteredOrders.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const pageNums = Array.from({ length: Math.min(totalPages, 4) }, (_, i) => i + 1);

  return (
    <div style={S.page}>
      {/* Header */}
      <div style={{ marginBottom: "6px" }}>
        <div style={S.breadcrumb}>Reports / <span style={{ color: "#0f172a" }}>Sales Report</span></div>
        <h1 style={S.pageTitle}>Sales Report</h1>
      </div>

      {/* Toolbar */}
      <div style={S.toolbar}>
        <div>
          <div style={S.label}>From Date</div>
          <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} style={S.input} />
        </div>
        <div>
          <div style={S.label}>To Date</div>
          <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} style={S.input} />
        </div>
        {QUICK.map((q) => (
          <button key={q} style={S.quickBtn(activeQuick === q)} onClick={() => setActiveQuick(q)}>{q}</button>
        ))}
        <button style={S.searchBtn}>Search</button>
        <button style={S.exportPdf}>📄 Export PDF</button>
        <button style={S.exportExcel}>📊 Export Excel</button>
      </div>

      {/* KPI Cards */}
      <div style={S.cardGrid}>
        <div style={S.card("#3b82f6")}>
          <div style={S.cardLeft}>
            <span style={S.cardLabel}>Total Orders</span>
            <span style={S.cardValue}>{salesReport.totalOrders}</span>
          </div>
          <div style={S.cardIcon}>🛒</div>
        </div>
        <div style={S.card("#10b981")}>
          <div style={S.cardLeft}>
            <span style={S.cardLabel}>Total Revenue</span>
            <span style={S.cardValue}>₹{salesReport.totalRevenue?.toLocaleString()}</span>
          </div>
          <div style={S.cardIcon}>💰</div>
        </div>
        <div style={S.card("#8b5cf6")}>
          <div style={S.cardLeft}>
            <span style={S.cardLabel}>Average Order Value</span>
            <span style={S.cardValue}>₹{averageOrderValue}</span>
          </div>
          <div style={S.cardIcon}>📈</div>
        </div>
        <div style={S.card("#f59e0b")}>
          <div style={S.cardLeft}>
            <span style={S.cardLabel}>Total Customers</span>
            <span style={S.cardValue}>{salesReport.totalCustomers}</span>
          </div>
          <div style={S.cardIcon}>👥</div>
        </div>
      </div>

      {/* Table */}
      <div style={S.tableWrap}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
          <div style={S.tableTitle}>Sales Orders</div>
          <input
            type="text"
            placeholder="Search customer..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            style={{ ...S.input, width: "220px" }}
          />
        </div>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                {["Invoice No", "Date", "Customer", "Mobile", "Store", "Amount", "Payment Mode"].map((h) => (
                  <th key={h} style={S.th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {currentOrders.length === 0 ? (
                <tr><td colSpan="7" style={{ ...S.td, textAlign: "center", padding: "28px" }}>No records found</td></tr>
              ) : currentOrders.map((order) => (
                <tr key={order.orderId}>
                  <td style={S.td}>INV-{String(order.orderId).padStart(4, "0")}</td>
                  <td style={S.td}>{new Date(order.orderDate).toLocaleDateString("en-IN")}</td>
                  <td style={S.td}>{order.customerName}</td>
                  <td style={S.td}>{order.phone}</td>
                  <td style={S.td}>{order.storeName || "—"}</td>
                  <td style={{ ...S.td, fontWeight: "600", color: "#0f172a" }}>₹{order.totalAmount?.toLocaleString()}</td>
                  <td style={S.td}>
                    <span style={{
                      padding: "3px 10px", borderRadius: "20px", fontSize: "12px", fontWeight: "600",
                      background: order.paymentMethod === "Cash" ? "#dcfce7" : order.paymentMethod === "UPI" ? "#eff6ff" : "#fef3c7",
                      color: order.paymentMethod === "Cash" ? "#16a34a" : order.paymentMethod === "UPI" ? "#2563eb" : "#92400e",
                    }}>{order.paymentMethod}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "18px" }}>
          <span style={{ fontSize: "13px", color: "#64748b" }}>
            Showing {Math.min((currentPage - 1) * itemsPerPage + 1, filteredOrders.length)}–{Math.min(currentPage * itemsPerPage, filteredOrders.length)} of {filteredOrders.length} orders
          </span>
          <div style={S.pag}>
            <button style={S.pagBtn(false)} onClick={() => setCurrentPage(Math.max(1, currentPage - 1))} disabled={currentPage === 1}>‹</button>
            {pageNums.map((n) => (
              <button key={n} style={S.pagBtn(n === currentPage)} onClick={() => setCurrentPage(n)}>{n}</button>
            ))}
            {totalPages > 4 && <span style={{ fontSize: "13px", color: "#64748b" }}>...</span>}
            <button style={S.pagBtn(false)} onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))} disabled={currentPage === totalPages}>›</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SalesReportPage;
