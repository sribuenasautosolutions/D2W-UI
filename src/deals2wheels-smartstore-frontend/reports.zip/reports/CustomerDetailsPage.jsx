import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
getCustomerDetails,
getCustomerOrderHistory,
} from "../../services/reportService";

function CustomerDetailsPage() {
const { id } = useParams();
const navigate = useNavigate();

const [customer, setCustomer] = useState(null);
const [orders, setOrders] = useState([]);

const [currentPage, setCurrentPage] =
useState(1);

const recordsPerPage = 10;

useEffect(() => {
loadData();
}, [id]);

const loadData = async () => {
try {
const customerData =
await getCustomerDetails(id);

  const orderData =
    await getCustomerOrderHistory(id);

  setCustomer(customerData);
  setOrders(orderData);
} catch (error) {
  console.error(error);
}

};

if (!customer) {
return (
<div style={{ padding: "30px" }}>
Loading Customer Details...
</div>
);
}

const totalPages = Math.ceil(
orders.length / recordsPerPage
);

const startIndex =
(currentPage - 1) * recordsPerPage;

const currentOrders =
orders.slice(
startIndex,
startIndex + recordsPerPage
);

return (
<div
style={{
padding: "30px",
background: "#f8fafc",
minHeight: "100vh",
}}
>
{/* HEADER */}

  <div
    style={{
      display: "flex",
      justifyContent:
        "space-between",
      alignItems: "center",
      marginBottom: "30px",
    }}
  >
    <div>
      <h1
        style={{
          margin: 0,
          color: "#0f172a",
        }}
      >
        Customer Details
      </h1>

      <p
        style={{
          color: "#64748b",
        }}
      >
        Customer profile and purchase history
      </p>
    </div>

    <button
      onClick={() =>
        navigate(
          "/admin/reports/customers"
        )
      }
      style={{
        background: "#0f172a",
        color: "#fff",
        border: "none",
        padding: "12px 18px",
        borderRadius: "10px",
        cursor: "pointer",
      }}
    >
      ← Back
    </button>
  </div>

  {/* KPI CARDS */}

  <div
    style={{
      display: "grid",
      gridTemplateColumns:
        "repeat(auto-fit,minmax(250px,1fr))",
      gap: "20px",
      marginBottom: "30px",
    }}
  >
    <div
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #2563eb",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <h4>Customer Name</h4>
      <h2>
        {customer.customerName}
      </h2>
    </div>

    <div
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #16a34a",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <h4>Total Orders</h4>
      <h2>
        {customer.totalOrders}
      </h2>
    </div>

    <div
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #9333ea",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <h4>Total Purchase</h4>
      <h2>
        ₹
        {Number(
          customer.totalPurchaseAmount
        ).toFixed(2)}
      </h2>
    </div>
  </div>

  {/* CUSTOMER INFO */}

  <div
    style={{
      background: "#fff",
      padding: "25px",
      borderRadius: "16px",
      marginBottom: "30px",
      boxShadow:
        "0 4px 15px rgba(0,0,0,0.08)",
    }}
  >
    <h3
      style={{
        marginBottom: "20px",
      }}
    >
      Customer Information
    </h3>

    <div
      style={{
        display: "grid",
        gridTemplateColumns:
          "repeat(auto-fit,minmax(250px,1fr))",
        gap: "20px",
      }}
    >
      <div>
        <strong>Mobile</strong>
        <p>{customer.phone}</p>
      </div>

      <div>
        <strong>Address</strong>
        <p>{customer.address}</p>
      </div>
    </div>
  </div>

  {/* ORDER HISTORY */}

  <div
    style={{
      background: "#fff",
      borderRadius: "16px",
      padding: "20px",
      boxShadow:
        "0 4px 15px rgba(0,0,0,0.08)",
    }}
  >
    <h3
      style={{
        marginBottom: "20px",
      }}
    >
      Purchase History
    </h3>

    <table
      style={{
        width: "100%",
        borderCollapse:
          "collapse",
      }}
    >
      <thead>
        <tr
          style={{
            background:
              "#f1f5f9",
          }}
        >
          <th style={{padding:"14px"}}>
            Invoice
          </th>

          <th style={{padding:"14px"}}>
            Customer
          </th>

          <th style={{padding:"14px"}}>
            Payment
          </th>

          <th style={{padding:"14px"}}>
            Date
          </th>

          <th style={{padding:"14px"}}>
            Amount
          </th>
        </tr>
      </thead>

      <tbody>
        {currentOrders.map(
          (order) => (
            <tr
              key={
                order.orderId
              }
            >
              <td
                style={{
                  padding:
                    "12px",
                }}
              >
                INV-
                {String(
                  order.orderId
                ).padStart(
                  6,
                  "0"
                )}
              </td>

              <td
                style={{
                  padding:
                    "12px",
                }}
              >
                {
                  order.customerName
                }
              </td>

              <td
                style={{
                  padding:
                    "12px",
                }}
              >
                {
                  order.paymentMethod
                }
              </td>

              <td
                style={{
                  padding:
                    "12px",
                }}
              >
                {new Date(
                  order.orderDate
                ).toLocaleDateString()}
              </td>

              <td
                style={{
                  padding:
                    "12px",
                  fontWeight:
                    "600",
                }}
              >
                ₹
                {Number(
                  order.totalAmount
                ).toFixed(
                  2
                )}
              </td>
            </tr>
          )
        )}
      </tbody>
    </table>

    {/* PAGINATION */}

    <div
      style={{
        display: "flex",
        justifyContent:
          "center",
        gap: "10px",
        marginTop: "20px",
      }}
    >
      <button
        disabled={
          currentPage === 1
        }
        onClick={() =>
          setCurrentPage(
            currentPage - 1
          )
        }
      >
        Previous
      </button>

      <span>
        Page {currentPage} of{" "}
        {totalPages}
      </span>

      <button
        disabled={
          currentPage ===
          totalPages
        }
        onClick={() =>
          setCurrentPage(
            currentPage + 1
          )
        }
      >
        Next
      </button>
    </div>
  </div>
</div>

);
}

export default CustomerDetailsPage;