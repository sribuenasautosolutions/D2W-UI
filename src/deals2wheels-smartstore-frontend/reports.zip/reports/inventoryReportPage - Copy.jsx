import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
getInventoryReport,
getInventoryItems,
} from "../../services/reportService";

function InventoryReportPage() {
const navigate = useNavigate();

const [inventoryReport,
setInventoryReport] = useState(null);

const [inventoryItems,
setInventoryItems] = useState([]);

const [tableData,
setTableData] = useState([]);

const [tableTitle,
setTableTitle] = useState(
"All Inventory Items"
);

const [search,
setSearch] = useState("");

useEffect(() => {
loadInventoryReport();
}, []);

const loadInventoryReport = async () => {
try {
const report =
await getInventoryReport();

  const items =
    await getInventoryItems();

  setInventoryReport(report);
  setInventoryItems(items);
  setTableData(items);
} catch (error) {
  console.error(error);
}

};

if (!inventoryReport) {
return (
<div style={{ padding: "30px" }}>
Loading Inventory Report...
</div>
);
}

const filteredData =
tableData.filter((item) =>
item.productName
?.toLowerCase()
.includes(
search.toLowerCase()
)
);

return (
<div
style={{
padding: "30px",
background: "#f8fafc",
minHeight: "100vh",
}}
>

  {/* HEADER */}

  <div
    style={{
      display: "flex",
      justifyContent:
        "space-between",
      alignItems: "center",
      marginBottom: "30px",
    }}
  >
    <div>
      <h1
        style={{
          margin: 0,
          color: "#0f172a",
        }}
      >
        Inventory Report
      </h1>

      <p
        style={{
          color: "#64748b",
          marginTop: "8px",
        }}
      >
        Stock quantity and inventory analysis
      </p>
    </div>

    <button
      onClick={() =>
        navigate(
          "/admin/reports"
        )
      }
      style={{
        background:
          "#0f172a",
        color: "#fff",
        border: "none",
        padding:
          "12px 18px",
        borderRadius: "10px",
        cursor: "pointer",
      }}
    >
      ← Back
    </button>
  </div>

  {/* KPI CARDS */}

  <div
    style={{
      display: "grid",
      gridTemplateColumns:
        "repeat(auto-fit,minmax(250px,1fr))",
      gap: "20px",
      marginBottom: "30px",
    }}
  >

    <div
      onClick={() => {
        setTableData(
          inventoryItems
        );
        setTableTitle(
          "All Inventory Items"
        );
      }}
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #2563eb",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
        cursor: "pointer",
      }}
    >
      <h4>Total Products</h4>
      <h1>
        {
          inventoryReport.totalProducts
        }
      </h1>
    </div>

    <div
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #16a34a",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <h4>Total Stock</h4>
      <h1>
        {
          inventoryReport.totalStockQuantity
        }
      </h1>
    </div>

    <div
      onClick={() => {
        const lowStock =
          inventoryItems.filter(
            (item) =>
              item.quantity <=
              item.minimumStock
          );

        setTableData(
          lowStock
        );

        setTableTitle(
          "Low Stock Products"
        );
      }}
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #f59e0b",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
        cursor: "pointer",
      }}
    >
      <h4>Low Stock</h4>
      <h1>
        {
          inventoryReport.lowStockItems
        }
      </h1>
    </div>

    <div
      onClick={() => {
        const outStock =
          inventoryItems.filter(
            (item) =>
              item.quantity ===
              0
          );

        setTableData(
          outStock
        );

        setTableTitle(
          "Out Of Stock Products"
        );
      }}
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #ef4444",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
        cursor: "pointer",
      }}
    >
      <h4>Out Of Stock</h4>
      <h1>
        {
          inventoryReport.outOfStockItems
        }
      </h1>
    </div>

  </div>

  {/* SEARCH */}

  <div
    style={{
      background: "#fff",
      padding: "20px",
      borderRadius: "16px",
      marginBottom: "20px",
      boxShadow:
        "0 4px 15px rgba(0,0,0,0.08)",
    }}
  >
    <input
      type="text"
      placeholder="Search Product..."
      value={search}
      onChange={(e) =>
        setSearch(
          e.target.value
        )
      }
      style={{
        width: "300px",
        padding: "12px",
        border:
          "1px solid #d1d5db",
        borderRadius:
          "10px",
      }}
    />
  </div>

  {/* TABLE */}

  <div
    style={{
      background: "#fff",
      padding: "20px",
      borderRadius: "16px",
      boxShadow:
        "0 4px 15px rgba(0,0,0,0.08)",
    }}
  >
    <h3
      style={{
        marginBottom: "20px",
      }}
    >
      {tableTitle}
    </h3>

    <div
      style={{
        overflowX: "auto",
      }}
    >
      <table
        style={{
          width: "100%",
          borderCollapse:
            "collapse",
        }}
      >
        <thead>
          <tr
            style={{
              background:
                "#f1f5f9",
            }}
          >
            <th style={{padding:"14px"}}>
              Product
            </th>

            <th style={{padding:"14px"}}>
              Store
            </th>

            <th style={{padding:"14px"}}>
              Quantity
            </th>

            <th style={{padding:"14px"}}>
              Minimum Stock
            </th>

            <th style={{padding:"14px"}}>
              Status
            </th>
          </tr>
        </thead>

        <tbody>
          {filteredData.length ===
          0 ? (
            <tr>
              <td
                colSpan="5"
                style={{
                  textAlign:
                    "center",
                  padding:
                    "20px",
                }}
              >
                No Records Found
              </td>
            </tr>
          ) : (
            filteredData.map(
              (item) => (
                <tr
                  key={
                    item.inventoryId
                  }
                  style={{
                    borderBottom:
                      "1px solid #e5e7eb",
                  }}
                >
                  <td
                    style={{
                      padding:
                        "12px",
                    }}
                  >
                    {
                      item.productName
                    }
                  </td>

                  <td
                    style={{
                      padding:
                        "12px",
                    }}
                  >
                    {
                      item.storeName
                    }
                  </td>

                  <td
                    style={{
                      padding:
                        "12px",
                      fontWeight:
                        "600",
                    }}
                  >
                    {
                      item.quantity
                    }
                  </td>

                  <td
                    style={{
                      padding:
                        "12px",
                    }}
                  >
                    {
                      item.minimumStock
                    }
                  </td>

                  <td
                    style={{
                      padding:
                        "12px",
                    }}
                  >
                    {
                      item.stockStatus
                    }
                  </td>
                </tr>
              )
            )
          )}
        </tbody>
      </table>
    </div>
  </div>

</div>

);
}

export default InventoryReportPage;