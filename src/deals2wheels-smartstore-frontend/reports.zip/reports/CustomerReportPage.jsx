import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
getCustomerReport,
getCustomerList,
} from "../../services/reportService";

function CustomerReportPage() {
const navigate = useNavigate();

const [report, setReport] = useState(null);
const [customers, setCustomers] = useState([]);
const [search, setSearch] = useState("");

useEffect(() => {
loadCustomerReport();
}, []);

const loadCustomerReport = async () => {
try {
const reportData =
await getCustomerReport();

  const customerData =
    await getCustomerList();

  setReport(reportData);
  setCustomers(customerData);
} catch (error) {
  console.error(error);
}

};

if (!report) {
return (
<div style={{ padding: "30px" }}>
Loading Customer Report...
</div>
);
}

const averageCustomerValue =
report.totalCustomers > 0
? report.totalPurchaseAmount /
report.totalCustomers
: 0;

const filteredCustomers =
customers.filter((customer) =>
customer.customerName
?.toLowerCase()
.includes(
search.toLowerCase()
)
);

return (
<div
style={{
padding: "30px",
background: "#f8fafc",
minHeight: "100vh",
}}
>

  {/* HEADER */}

  <div
    style={{
      display: "flex",
      justifyContent:
        "space-between",
      alignItems: "center",
      marginBottom: "30px",
    }}
  >
    <div>
      <h1
        style={{
          margin: 0,
          color: "#0f172a",
        }}
      >
        Customer Report
      </h1>

      <p
        style={{
          color: "#64748b",
          marginTop: "8px",
        }}
      >
        Customer purchase history and spending analysis
      </p>
    </div>

    <button
      onClick={() =>
        navigate(
          "/admin/reports"
        )
      }
      style={{
        background:
          "#0f172a",
        color: "#fff",
        border: "none",
        padding:
          "12px 18px",
        borderRadius: "10px",
        cursor: "pointer",
      }}
    >
      ← Back
    </button>
  </div>

  {/* KPI CARDS */}

  <div
    style={{
      display: "grid",
      gridTemplateColumns:
        "repeat(auto-fit,minmax(250px,1fr))",
      gap: "20px",
      marginBottom: "30px",
    }}
  >

    <div
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #2563eb",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <h4>Total Customers</h4>
      <h1>
        {report.totalCustomers}
      </h1>
    </div>

    <div
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #16a34a",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <h4>Total Orders</h4>
      <h1>
        {report.totalOrders}
      </h1>
    </div>

    <div
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #9333ea",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <h4>Total Purchase</h4>
      <h1>
        ₹
        {report.totalPurchaseAmount}
      </h1>
    </div>

    <div
      style={{
        background: "#fff",
        padding: "25px",
        borderRadius: "16px",
        borderTop:
          "5px solid #f59e0b",
        boxShadow:
          "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <h4>Avg Customer Value</h4>
      <h1>
        ₹
        {averageCustomerValue.toFixed(
          2
        )}
      </h1>
    </div>

  </div>

  {/* SEARCH */}

  <div
    style={{
      background: "#fff",
      padding: "20px",
      borderRadius: "16px",
      marginBottom: "20px",
      boxShadow:
        "0 4px 15px rgba(0,0,0,0.08)",
    }}
  >
    <input
      type="text"
      placeholder="Search Customer..."
      value={search}
      onChange={(e) =>
        setSearch(
          e.target.value
        )
      }
      style={{
        width: "300px",
        padding: "12px",
        border:
          "1px solid #d1d5db",
        borderRadius:
          "10px",
      }}
    />
  </div>

  {/* CUSTOMER TABLE */}

  <div
    style={{
      background: "#fff",
      padding: "20px",
      borderRadius: "16px",
      boxShadow:
        "0 4px 15px rgba(0,0,0,0.08)",
    }}
  >
    <h3
      style={{
        marginBottom: "20px",
      }}
    >
      Customer List
    </h3>

    <div
      style={{
        overflowX: "auto",
      }}
    >
      <table
        style={{
          width: "100%",
          borderCollapse:
            "collapse",
        }}
      >
        <thead>
          <tr
            style={{
              background:
                "#f1f5f9",
            }}
          >
            <th style={{padding:"14px"}}>
              Customer
            </th>

            <th style={{padding:"14px"}}>
              Mobile
            </th>

            <th style={{padding:"14px"}}>
              Orders
            </th>

            <th style={{padding:"14px"}}>
              Purchase Amount
            </th>
          </tr>
        </thead>

        <tbody>
          {filteredCustomers.map(
            (customer) => (
              <tr
                key={
                  customer.customerId
                }
                style={{
                  borderBottom:
                    "1px solid #e5e7eb",
                }}
              >
                <td
                  style={{
                    padding:
                      "12px",
                    color:
                      "#2563eb",
                    cursor:
                      "pointer",
                    fontWeight:
                      "600",
                  }}
                  onClick={() =>
                    navigate(
                      `/admin/reports/customer/${customer.customerId}`
                    )
                  }
                >
                  {
                    customer.customerName
                  }
                </td>

                <td
                  style={{
                    padding:
                      "12px",
                  }}
                >
                  {
                    customer.phone
                  }
                </td>

                <td
                  style={{
                    padding:
                      "12px",
                    textAlign:
                      "center",
                  }}
                >
                  {
                    customer.totalOrders
                  }
                </td>

                <td
                  style={{
                    padding:
                      "12px",
                    fontWeight:
                      "600",
                  }}
                >
                  ₹
                  {
                    customer.totalPurchaseAmount
                  }
                </td>
              </tr>
            )
          )}
        </tbody>
      </table>
    </div>
  </div>

</div>

);
}

export default CustomerReportPage;